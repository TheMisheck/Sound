
function notification(type){
  alert(type);
}
function help(type){
    alert(type);
}
function news(type){
    alert(type)
}